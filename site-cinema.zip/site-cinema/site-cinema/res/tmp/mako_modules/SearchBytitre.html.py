# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835244.7212193
_enable_loop = True
_template_filename = 'res/templates/SearchBytitre.html'
_template_uri = 'SearchBytitre.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        len = context.get('len', UNDEFINED)
        mesTitres = context.get('mesTitres', UNDEFINED)
        message = context.get('message', UNDEFINED)
        type = context.get('type', UNDEFINED)
        range = context.get('range', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<h3 class="julien">Liste des Films</h3>\r\n\r\n\r\n\r\n')

        maListe = []
        from Web import FilmTitre
        Film = FilmTitre()
        for Nom, duree in Film:
            maListe.append(Nom)
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['Nom','Film','duree','maListe','FilmTitre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n\r\n<form action="AffFilm" method="POST" class="needs-validation" novalidate>\r\n  <div class="form-group">\r\n    <label class="choix" for="titre">Titre: </label>\r\n    <select class="form-control" name="titre" id="titre" required>\r\n')
        for i in range(len(maListe)):
            __M_writer('    <option value="')
            __M_writer(str(maListe[i]))
            __M_writer('">')
            __M_writer(str(maListe[i]))
            __M_writer('</option>\r\n')
        __M_writer('    </select>\r\n  </div>\r\n  <br><br>\r\n  <button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n\r\n\r\n\r\n<br>\r\n')
 
        maListe = []
        from Web import convertir_minutes_en_heures
        for titre, duree, annee, catego, desc, interdi, prix in mesTitres :
            maListe.append((titre, convertir_minutes_en_heures(duree), annee, catego, desc, interdi, prix)) 
            
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['convertir_minutes_en_heures','interdi','catego','desc','duree','prix','maListe','annee','titre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for titre, duree, annee, catego, desc, interdi, prix in maListe :
            __M_writer('    <b>')
            __M_writer(str(titre))
            __M_writer('</b> :<br>durée: ')
            __M_writer(str(duree))
            __M_writer(' minutes <br>')
            __M_writer(str(annee))
            __M_writer(' <br>')
            __M_writer(str(catego))
            __M_writer(' <br>')
            __M_writer(str(desc))
            __M_writer(' <br>Interdiction : ')
            __M_writer(str(interdi))
            __M_writer(' <br>Prix: ')
            __M_writer(str(prix))
            __M_writer('€<br/>\r\n')
        __M_writer('\r\n')
        __M_writer('\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/SearchBytitre.html", "uri": "SearchBytitre.html", "source_encoding": "utf-8", "line_map": {"27": 0, "37": 1, "38": 2, "39": 4, "40": 4, "41": 4, "42": 4, "43": 9, "44": 10, "45": 11, "46": 12, "47": 13, "48": 14, "49": 15, "50": 16, "53": 15, "54": 21, "55": 22, "56": 22, "57": 22, "58": 22, "59": 22, "60": 24, "61": 33, "62": 34, "63": 35, "64": 36, "65": 37, "66": 38, "67": 39, "70": 38, "71": 39, "72": 40, "73": 40, "74": 40, "75": 40, "76": 40, "77": 40, "78": 40, "79": 40, "80": 40, "81": 40, "82": 40, "83": 40, "84": 40, "85": 40, "86": 40, "87": 42, "88": 43, "94": 88}}
__M_END_METADATA
"""
