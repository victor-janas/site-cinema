# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685833990.5102854
_enable_loop = True
_template_filename = 'res/templates/template_Reservation.html'
_template_uri = 'template_Reservation.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        self = context.get('self', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html >\r\n<html lang="fr">\r\n<head>\r\n<title>Ducinema</title>\r\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n<link href="res/css/style.css" rel="stylesheet" type="text/css" />\r\n<script src="res/js/jquery-1.4.2.min.js" type="text/javascript"></script>\r\n<script src="res/js/cufon-yui.js" type="text/javascript"></script>\r\n<script src="res/js/cufon-replace.js" type="text/javascript"></script>\r\n<script src="res/js/Gill_Sans_400.font.js" type="text/javascript"></script>\r\n<script src="res/js/script.js" type="text/javascript"></script>\r\n\r\n</head>\r\n<body id="page5">\r\n<!-- START PAGE SOURCE -->\r\n<div class="tail-top">\r\n  <div class="tail-bottom">\r\n    <div id="main">\r\n      <div id="header">\r\n        <div class="row-1">\r\n          <div class="fleft"><a href="index">Ducinema <span>SAE 23 Victor JANAS</span></a></div>\r\n          <ul>\r\n            <li><a href="index"><img src="res/images/icon1.gif" alt="Accueil" /></a></li>\r\n            <li><a href="Recherche"><img src="res/images/icon2-act.png" alt="Recherche" /></a></li>\r\n            <li><a href="Administration"><img src="res/images/icon3.gif" alt="Administration" /></a></li>\r\n          </ul>\r\n        </div>\r\n        <div class="row-2">\r\n          <ul>\r\n            <li><a href="index" >Accueil</a></li>\r\n            <li><a href="Recherche">Recherche</a></li>\r\n            <li><a href="Seances">Séances</a></li>\r\n            <li><a href="Reservation" class="active">Réservation</a></li>\r\n            <li class="last"><a href="Administration">Administration</a></li>\r\n          </ul>\r\n        </div>\r\n      </div>\r\n      <div class="content">\r\n        <h3>Les <span>Réservations</span></h3>\r\n        <ul class="list">\r\n          <li><img src="res/images/reservation.jpg" alt="reservation" width="120px" /><a href="affPageRes">Réserver</a><br />\r\n            Permet de réserver pour une séance, avant de réserver il faut connaitre la date, l\'horaire et le titre du film</li>\r\n            <li><img src="res/images/reservation-date.jpg" alt="reservation-date" width="120px" /><a href="affRes">Toutes les Réservations</a><br />\r\n            Pour pouvoir regarder l\'ensemble des réservations au cinéma</li>\r\n            <li><img src="res/images/reservation3.gif" alt="reservation3" width="120px"/><a href="affPageResNom">Les réservations par personne</a><br />\r\n              Pour pouvoir regarder les réservations par personne au cinéma</li>\r\n            <li><img src="res/images/reservation4.webp" alt="reservation4" width="120px"/><a href="affPageResDate">Les réservations par date</a><br />\r\n              Pour pouvoir regarder les réservations par date au cinéma</li>\r\n            <li><img src="res/images/reservation5.png" alt="reservation5" width="120px"/><a href="affPageResTitre">Les réservations par Film</a><br />\r\n              Pour pouvoir regarder les réservations par film au cinéma</li>\r\n\r\n          </ul>\r\n      </div>\r\n    </div>\r\n      <script type="text/javascript"> Cufon.now(); </script>\r\n    ')
        __M_writer(str(self.body()))
        __M_writer('\r\n</body>\r\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/template_Reservation.html", "uri": "template_Reservation.html", "source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 56, "24": 56, "30": 24}}
__M_END_METADATA
"""
