# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685833881.772901
_enable_loop = True
_template_filename = 'res/templates/Seances.html'
_template_uri = 'Seances.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template_Seances.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        __M_writer('\r\n      <div id="content">\r\n        <div class="line-hor"></div>\r\n        <div class="box">\r\n          <div class="border-right">\r\n            <div class="border-left">\r\n              <div class="inner">\r\n                <h3>Nos <span>Séances</span></h3>\r\n                <p>Bienvenue sur notre page dédiée aux séances de cinéma ! Nous sommes là pour vous aider à planifier votre prochaine sortie cinématographique et vous offrir une expérience inoubliable.\r\n                  Sur notre site, vous trouverez toutes les informations essentielles sur les séances de cinéma disponibles près de chez vous. Que vous préfériez les blockbusters palpitants, les films d\'auteur captivants ou les documentaires inspirants, notre plateforme vous permettra de consulter facilement les horaires, les salles de projection et les films en cours de diffusion.</p>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        \r\n        <div id="footer">\r\n          <div class="left">\r\n            <div class="right">\r\n              <div class="footerlink">\r\n                <p class="lf">Victor Janas SAE23</p>\r\n                <p class="rf">Site sur le cinéma</p>\r\n                <div style="clear:both;"></div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  ')
        __M_writer('\r\n  ')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/Seances.html", "uri": "Seances.html", "source_encoding": "utf-8", "line_map": {"27": 0, "32": 1, "33": 30, "39": 33}}
__M_END_METADATA
"""
