# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835782.7247972
_enable_loop = True
_template_filename = 'res/templates/SearchByResTitre.html'
_template_uri = 'SearchByResTitre.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        mesTitres = context.get('mesTitres', UNDEFINED)
        len = context.get('len', UNDEFINED)
        range = context.get('range', UNDEFINED)
        type = context.get('type', UNDEFINED)
        str = context.get('str', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<h3 class="julien">Liste des Films</h3>\r\n\r\n')

        maListe = []
        from Web import FilmTitre
        Film = FilmTitre()
        for Nom, duree in Film:
            maListe.append(Nom)
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['Film','maListe','duree','Nom','FilmTitre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n\r\n<form action="AffResTitre" method="POST" class="needs-validation" novalidate>\r\n  <div class="form-group">\r\n    <label class="choix" for="titre">Titre: </label>\r\n    <select class="form-control" name="titre" id="titre" required>\r\n')
        for i in range(len(maListe)):
            __M_writer('    <option value="')
            __M_writer(str(maListe[i]))
            __M_writer('">')
            __M_writer(str(maListe[i]))
            __M_writer('</option>\r\n')
        __M_writer('    </select>\r\n  </div>\r\n  <br><br>\r\n  <button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n\r\n\r\n<br>\r\n')
      
        maListe = []
        from Web import isoDate2String
        for prenom,nom,titre,date,horaire in mesTitres :
            maListe.append((prenom,nom,titre,horaire,isoDate2String(str(date)))) 
            
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['isoDate2String','titre','horaire','maListe','prenom','date','nom'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for nom, prenom,titre,date,horaire in maListe :
            __M_writer('    <b> <br> ')
            __M_writer(str(nom))
            __M_writer(' ')
            __M_writer(str(prenom))
            __M_writer(' <br> Le : ')
            __M_writer(str(date))
            __M_writer(' à ')
            __M_writer(str(horaire))
            __M_writer(' <br><br></b>\r\n')
        __M_writer('\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/SearchByResTitre.html", "uri": "SearchByResTitre.html", "source_encoding": "utf-8", "line_map": {"27": 0, "38": 1, "39": 2, "40": 4, "41": 4, "42": 4, "43": 4, "44": 7, "45": 8, "46": 9, "47": 10, "48": 11, "49": 12, "50": 13, "51": 14, "54": 13, "55": 19, "56": 20, "57": 20, "58": 20, "59": 20, "60": 20, "61": 22, "62": 30, "63": 31, "64": 32, "65": 33, "66": 34, "67": 35, "68": 36, "71": 35, "72": 36, "73": 37, "74": 37, "75": 37, "76": 37, "77": 37, "78": 37, "79": 37, "80": 37, "81": 37, "82": 39, "88": 82}}
__M_END_METADATA
"""
