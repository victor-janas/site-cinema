# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835458.941019
_enable_loop = True
_template_filename = 'res/templates/SearchByNation.html'
_template_uri = 'SearchByNation.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        Nation = context.get('Nation', UNDEFINED)
        mesTitres = context.get('mesTitres', UNDEFINED)
        len = context.get('len', UNDEFINED)
        range = context.get('range', UNDEFINED)
        type = context.get('type', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<h3 class="julien">Liste des nationalités</h3>\r\n\r\n')

        maListe = []
        from Web import FilmNation
        Country = FilmNation()
        for nation, titre in Country:
            maListe.append(nation)
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['titre','FilmNation','Country','maListe','nation'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n\r\n<form action="AffNation" method="POST" class="needs-validation" novalidate>\r\n  <div class="form-group">\r\n    <label class="choix" for="nations">Pays : </label>\r\n    <select class="form-control" name="nations" id="nations" required>\r\n')
        for i in range(len(maListe)):
            __M_writer('    <option value="')
            __M_writer(str(maListe[i]))
            __M_writer('">')
            __M_writer(str(maListe[i]))
            __M_writer('</option>\r\n')
        __M_writer('    </select>\r\n  </div>\r\n  <br><br>\r\n  <button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n\r\n\r\n<br>\r\n\r\n  <p class="julien">')
        __M_writer(str(Nation))
        __M_writer(' :</p> <br> \r\n  ')
  
        maListe = []
        for titre, nation in mesTitres :
            maListe.append((titre,nation)) 
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['maListe','nation','titre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for titre,nation in maListe :
            __M_writer('<b>')
            __M_writer(str(titre))
            __M_writer(' </b> <br> \r\n')
        __M_writer('\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/SearchByNation.html", "uri": "SearchByNation.html", "source_encoding": "utf-8", "line_map": {"27": 0, "38": 1, "39": 3, "40": 3, "41": 3, "42": 3, "43": 6, "44": 7, "45": 8, "46": 9, "47": 10, "48": 11, "49": 12, "50": 13, "53": 12, "54": 18, "55": 19, "56": 19, "57": 19, "58": 19, "59": 19, "60": 21, "61": 30, "62": 30, "63": 31, "64": 32, "65": 33, "66": 34, "67": 35, "68": 36, "71": 35, "72": 36, "73": 37, "74": 37, "75": 37, "76": 39, "82": 76}}
__M_END_METADATA
"""
