# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835481.556538
_enable_loop = True
_template_filename = 'res/templates/SearchByCatego.html'
_template_uri = 'SearchByCatego.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        mesTitres = context.get('mesTitres', UNDEFINED)
        Catego = context.get('Catego', UNDEFINED)
        type = context.get('type', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<h3 class="julien">Liste des nationalité</h3>\r\n\r\n\r\n\r\n<form action="AffCatego" method="POST" class="needs-validation" novalidate>\r\n  <div class="form-group">\r\n    <label for="catego">catégorie:</label>\r\n    <select class="form-control" name="catego" id="catego" required>\r\n        <option value="policier">policier</option>\r\n        <option value="fantastique">fantastique</option>\r\n        <option value="aventure">aventure</option>\r\n        <option value="psychologique">psychologique</option>\r\n        <option value="documentaire">documentaire</option>\r\n        <option value="historique">historique</option>\r\n        <option value="autre">autre</option>\r\n      </select>\r\n  </div>\r\n  <br>\r\n  <button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n\r\n<br>\r\n\r\n  <p>')
        __M_writer(str(Catego))
        __M_writer(' : </p>\r\n  ')
 
        maListe = []
        for titre, categorie in mesTitres :
            maListe.append((titre,categorie)) 
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['maListe','categorie','titre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for titre,categorie in maListe :
            __M_writer('<b>')
            __M_writer(str(titre))
            __M_writer(' </b> <br> \r\n')
        __M_writer('\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/SearchByCatego.html", "uri": "SearchByCatego.html", "source_encoding": "utf-8", "line_map": {"27": 0, "36": 1, "37": 2, "38": 4, "39": 4, "40": 4, "41": 4, "42": 28, "43": 28, "44": 29, "45": 30, "46": 31, "47": 32, "48": 33, "49": 34, "52": 33, "53": 34, "54": 35, "55": 35, "56": 35, "57": 37, "63": 57}}
__M_END_METADATA
"""
