# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835761.4556031
_enable_loop = True
_template_filename = 'res/templates/SearchByResNom.html'
_template_uri = 'SearchByResNom.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        mesTitres = context.get('mesTitres', UNDEFINED)
        type = context.get('type', UNDEFINED)
        str = context.get('str', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<h3 class="julien">Liste des Films</h3>\r\n\r\n<div class="field">\r\n <form id="contacts-form" action="AffResNom" method="POST" class="needs-validation" novalidate>\r\n  <fieldset>\r\n  <div class="field">\r\n    <label for="nom">Nom:</label>\r\n    <input type="text" class="form-control" id="nom" placeholder="Entrer le nom" name="nom" required>\r\n    <br>\r\n    <br>\r\n  <br>\r\n    <label for="prenom">Prenom:</label>\r\n    <input type="text" class="form-control" id="prenom" placeholder="Entrer le prenom" name="prenom" required>\r\n  </div>\r\n  </fieldset>\r\n  <br>\r\n  <br>\r\n  <br>\r\n  <br>\r\n  <br>\r\n  <br>\r\n  <button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n<br>\r\n')
      
        maListe = []
        from Web import isoDate2String
        for prenom,nom,titre,date,horaire in mesTitres :
            maListe.append((prenom,nom,titre,horaire,isoDate2String(str(date)))) 
            
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['isoDate2String','titre','horaire','maListe','prenom','date','nom'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for nom, prenom,titre,date,horaire in maListe :
            __M_writer('    <b>')
            __M_writer(str(titre))
            __M_writer(':</b> <br> ')
            __M_writer(str(nom))
            __M_writer(' ')
            __M_writer(str(prenom))
            __M_writer(' <br> Le : ')
            __M_writer(str(horaire))
            __M_writer(' à ')
            __M_writer(str(date))
            __M_writer(' <br><br>\r\n')
        __M_writer('\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/SearchByResNom.html", "uri": "SearchByResNom.html", "source_encoding": "utf-8", "line_map": {"27": 0, "36": 1, "37": 2, "38": 4, "39": 4, "40": 4, "41": 4, "42": 29, "43": 30, "44": 31, "45": 32, "46": 33, "47": 34, "48": 35, "51": 34, "52": 35, "53": 36, "54": 36, "55": 36, "56": 36, "57": 36, "58": 36, "59": 36, "60": 36, "61": 36, "62": 36, "63": 36, "64": 38, "70": 64}}
__M_END_METADATA
"""
