# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835500.570859
_enable_loop = True
_template_filename = 'res/templates/affPageInterdit.html'
_template_uri = 'affPageInterdit.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        film = context.get('film', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n\r\n<h3>\r\nAffichage de tous les films interdits\r\n</h3>\r\n<h3 class="julien">Liste des Films</h3>\r\n\r\n')

        maListe = []
        from Web import convertir_minutes_en_heures
        for titre,description,prix,anneeTournage,categorie,duree in film :
            maListe.append((titre,description,prix,anneeTournage,categorie,convertir_minutes_en_heures(duree))) 
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['convertir_minutes_en_heures','titre','anneeTournage','description','maListe','categorie','duree','prix'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for titre,description,prix,anneeTournage,categorie,duree in maListe :
            __M_writer('<b>')
            __M_writer(str(titre))
            __M_writer('  <br>Description :</b>  ')
            __M_writer(str(description))
            __M_writer(' <br><b> Prix </b>: ')
            __M_writer(str(prix))
            __M_writer('€<br><b> Réalisé en :</b> ')
            __M_writer(str(anneeTournage))
            __M_writer('<br><b> Catégorie : </b> ')
            __M_writer(str(categorie))
            __M_writer('<br><b> Durée :</b> ')
            __M_writer(str(duree))
            __M_writer(' <br> <br>\r\n')
        __M_writer('\r\n')
        __M_writer('\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/affPageInterdit.html", "uri": "affPageInterdit.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 2, "35": 9, "36": 10, "37": 11, "38": 12, "39": 13, "40": 14, "41": 15, "44": 14, "45": 15, "46": 16, "47": 16, "48": 16, "49": 16, "50": 16, "51": 16, "52": 16, "53": 16, "54": 16, "55": 16, "56": 16, "57": 16, "58": 16, "59": 18, "60": 19, "66": 60}}
__M_END_METADATA
"""
