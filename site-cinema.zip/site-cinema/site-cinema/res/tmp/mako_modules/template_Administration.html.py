# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685833994.3060877
_enable_loop = True
_template_filename = 'res/templates/template_Administration.html'
_template_uri = 'template_Administration.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        self = context.get('self', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html >\r\n<html lang="fr">\r\n<head>\r\n<title>Ducinema</title>\r\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n<link href="res/css/style.css" rel="stylesheet" type="text/css" />\r\n<script src="res/js/jquery-1.4.2.min.js" type="text/javascript"></script>\r\n<script src="res/js/cufon-yui.js" type="text/javascript"></script>\r\n<script src="res/js/cufon-replace.js" type="text/javascript"></script>\r\n<script src="res/js/Gill_Sans_400.font.js" type="text/javascript"></script>\r\n<script src="res/js/script.js" type="text/javascript"></script>\r\n\r\n</head>\r\n<body id="page1">\r\n<!-- START PAGE SOURCE -->\r\n<div class="tail-top">\r\n  <div class="tail-bottom">\r\n    <div id="main">\r\n      <div id="header">\r\n        <div class="row-1">\r\n          <div class="fleft"><a href="index">Ducinema <span>SAE 23 Victor JANAS</span></a></div>\r\n          <ul>\r\n            <li><a href="index"><img src="res/images/icon1.gif" alt="Accueil" /></a></li>\r\n            <li><a href="Recherche"><img src="res/images/icon2.png" alt="Recherche" /></a></li>\r\n            <li><a href="Administration"><img src="res/images/icon3-act.gif" alt="Administration" /></a></li>\r\n          </ul>\r\n        </div>\r\n        <div class="row-2">\r\n          <ul>\r\n            <li><a href="index" >Accueil</a></li>\r\n            <li><a href="Recherche">Recherche</a></li>\r\n            <li><a href="Seances">Séances</a></li>\r\n            <li><a href="Reservation">Réservation</a></li>\r\n            <li class="last"><a href="Administration"  class="active">Administration</a></li>\r\n          </ul>\r\n        </div>\r\n      </div>\r\n      <div class="content">\r\n        <br>\r\n        <h3>Les <span>Insertions</span></h3>\r\n        <ul class="list">\r\n          <li><a href="affPageInsertFilm">Insérer un film</a><br />\r\n          Permet d\'insérer un nouveau film dans les données du cinéma</li>\r\n            <li><a href="affPageInsertParticipant">Insérer un participant</a><br />\r\n          Permet d\'insérer un nouveau participant</li>\r\n            <li><a href="affPageInsertRelationActeur">Relier un acteur à un film</a><br />\r\n          Permet de renseigner un acteur dans un film, l\'acteur doit déja exister dans les données du site</li>\r\n            <li><a href="affPageInsertRelationReal">Relier un réalisateur à un film</a><br />\r\n          Permet de renseigner un réalisateur dans un film, le réalisateur doit déja exister dans les données du site</li>\r\n            <li><a href="affPageInsertSeance">Insérer une séance</a><br />\r\n          Permet d\'ajouter une séance pour un film. Le film doit déja exister dans la base.</li>\r\n          </ul>\r\n          <br>\r\n          <h3>Les <span>suppressions</span></h3>\r\n          <ul class="list">\r\n            <li><a href="affPageDeleteFilm">Supprimer un film</a><br />\r\n            Permet de supprimer un film dans les données du cinéma</li>\r\n              <li><a href="affPageDeleteParticipant">Supprimer un participant</a><br />\r\n            Permet de supprimer un participant</li>\r\n              <li><a href="affPageDeleteSeance">Supprimer une séance</a><br />\r\n            Permet de supprimer une séance</li>\r\n              <li><a href="affPageDeleteRes">Supprimer une réservation</a><br />\r\n            Permet de supprimer une réservation</li>\r\n            <li><a href="affPageDeleteRelationAct">Supprimer un acteur d\'un film</a><br />\r\n              Permet de ne plus faire apparaitre une personne comme l\'acteur d\'un film</li>\r\n                <li><a href="affPageDeleteRelationReal">Supprimer un réalisateur d\'un film</a><br />\r\n              Permet de ne plus faire apparaitre une personne comme le réalisateur d\'un film</li>\r\n            </ul>\r\n            <br>\r\n            <h3>Les <span>modifications</span></h3>\r\n            <ul class="list">\r\n            <li><a href="affPageUpdateFilm">Modifier un film</a><br />\r\n              Permet de modifier un film dans les données du cinéma</li>\r\n            <li><a href="affPageUpdateParticipant">Modifier un participant</a><br />\r\n              Permet de modifier un participant</li>\r\n            <li><a href="affPageUpdateSeance">Modifier une séance</a><br />\r\n              Permet de modifier une séance</li>\r\n            <li><a href="affPageUpdateReservation">Modifier une réservation</a><br />\r\n            Permet de modifier une réservation</li>\r\n          </ul>\r\n      </div>\r\n    </div>\r\n      <script type="text/javascript"> Cufon.now(); </script>\r\n<!-- END PAGE SOURCE -->\r\n    ')
        __M_writer(str(self.body()))
        __M_writer('\r\n</body>\r\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/template_Administration.html", "uri": "template_Administration.html", "source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 85, "24": 85, "30": 24}}
__M_END_METADATA
"""
