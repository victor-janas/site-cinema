# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1684930013.6169107
_enable_loop = True
_template_filename = 'res/templates/affPageInsertRelationActeur.html'
_template_uri = 'affPageInsertRelationActeur.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        type = context.get('type', UNDEFINED)
        message = context.get('message', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\n<br>\n<p class="message alert alert-')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\n\n\n<div class="field">\n <form id="contacts-form" action="InsertRelationActeur" method="POST" class="needs-validation" novalidate>\n  <fieldset>\n  <div class="field">\n    <label for="nom">Nom:</label>\n    <input type="text" class="form-control" id="nom" placeholder="Entrer le nom" name="nom" required>\n    <br>\n    <br>\n  <br>\n    <label for="prenom">Prenom:</label>\n    <input type="text" class="form-control" id="prenom" placeholder="Entrer le prenom" name="prenom" required>\n    <br>\n    <br>\n      <label for="titre">Titre :</label>\n      <input type="text" class="form-control" id="titre" placeholder="Entrer le titre" name="titre" required>\n  </div>\n  </fieldset>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <br>\n  <button type="submit" class="btn btn-primary">Rechercher</button>\n</form>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/affPageInsertRelationActeur.html", "uri": "affPageInsertRelationActeur.html", "source_encoding": "utf-8", "line_map": {"27": 0, "34": 1, "35": 3, "36": 3, "37": 3, "38": 3, "44": 38}}
__M_END_METADATA
"""
