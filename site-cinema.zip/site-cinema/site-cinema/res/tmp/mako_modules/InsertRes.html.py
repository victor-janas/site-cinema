# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835673.4454606
_enable_loop = True
_template_filename = 'res/templates/InsertRes.html'
_template_uri = 'InsertRes.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        type = context.get('type', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<p class="julien">La séance et le film doivent se trouver dans la base</p>\r\n\r\n<div class="field">\r\n  <form id="contacts-form" action="InsertRes" method="POST" class="needs-validation" novalidate>\r\n    <fieldset>\r\n      <div class="form-group">\r\n        <label for="nom">Nom:</label>\r\n        <input type="text" class="form-control" id="nom" placeholder="Entrer le nom" name="nom" required>\r\n      </div>\r\n      <br>\r\n      <div class="field">\r\n        <label for="prenom">Prenom:</label>\r\n        <input type="text" class="form-control" id="prenom" placeholder="Entrer le prenom" name="prenom" required>\r\n      </div>\r\n      <br>\r\n      <div class="field">\r\n        <label for="date">Date :</label>\r\n        <input  class="white" type="date" class="form-control" id="date" placeholder="Date" name="date" required>\r\n      </div>\r\n      <br>\r\n      <div class="field">\r\n        <label for="horaire">Horaire :</label>\r\n        <input type="time" class="form-control" id="horaire" placeholder="Entrer l\'horaire" name="horaire" required> \r\n      </div>\r\n      <br>\r\n      <div class="field">\r\n        <label for="titre">Titre:</label>\r\n        <input type="text" class="form-control" id="titre" placeholder="Entrer le titre" name="titre" required>  \r\n      </div>\r\n      </fieldset>\r\n      <br><br><br><br><br><br><br><br><br><br><br><br><br><br>\r\n      <button type="submit" class="btn btn-primary">Rechercher</button>\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/InsertRes.html", "uri": "InsertRes.html", "source_encoding": "utf-8", "line_map": {"27": 0, "34": 1, "35": 2, "36": 4, "37": 4, "38": 4, "39": 4, "45": 39}}
__M_END_METADATA
"""
