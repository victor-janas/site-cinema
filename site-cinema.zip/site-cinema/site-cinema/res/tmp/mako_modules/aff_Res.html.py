# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835715.957091
_enable_loop = True
_template_filename = 'res/templates/aff_Res.html'
_template_uri = 'aff_Res.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        film = context.get('film', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<h3 class="julien">Ensemble des réservations :</h3>\r\n')
 
        maListe = []
        for titre, duree, annee, catego in film :
            maListe.append((titre, duree, annee, catego)) 
            
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['catego','annee','titre','maListe','duree'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for titre, duree, annee, catego in maListe :
            __M_writer('   <p> ')
            __M_writer(str(titre))
            __M_writer(' : ')
            __M_writer(str(duree))
            __M_writer(' ')
            __M_writer(str(annee))
            __M_writer(' ')
            __M_writer(str(catego))
            __M_writer(' </p><br/>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/aff_Res.html", "uri": "aff_Res.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 4, "35": 5, "36": 6, "37": 7, "38": 8, "39": 9, "42": 8, "43": 9, "44": 10, "45": 10, "46": 10, "47": 10, "48": 10, "49": 10, "50": 10, "51": 10, "52": 10, "58": 52}}
__M_END_METADATA
"""
