# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1684955174.2497692
_enable_loop = True
_template_filename = 'res/templates/affPageDate.html'
_template_uri = 'affPageDate.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        type = context.get('type', UNDEFINED)
        message = context.get('message', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n\r\n\r\n<form action="AffDate" method="POST" class="needs-validation" novalidate>\r\n    <div class="form-group">\r\n        <label class="form">\r\n        <label for="date">Date :</label>\r\n        <input type="date" class="form-control" id="date" placeholder="Date" name="date" required>\r\n        </label>\r\n  </div>\r\n  <br>\r\n  <button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n\r\n\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/affPageDate.html", "uri": "affPageDate.html", "source_encoding": "utf-8", "line_map": {"27": 0, "34": 1, "35": 3, "36": 3, "37": 3, "38": 3, "44": 38}}
__M_END_METADATA
"""
