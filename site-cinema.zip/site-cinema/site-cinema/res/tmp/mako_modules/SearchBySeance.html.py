# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835534.9263604
_enable_loop = True
_template_filename = 'res/templates/SearchBySeance.html'
_template_uri = 'SearchBySeance.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        mesTitres = context.get('mesTitres', UNDEFINED)
        len = context.get('len', UNDEFINED)
        range = context.get('range', UNDEFINED)
        Titre = context.get('Titre', UNDEFINED)
        type = context.get('type', UNDEFINED)
        str = context.get('str', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<h3 class="julien">Liste des horaires</h3>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n\r\n\r\n\r\n  ')

        maListe = []
        from Web import FilmTitre
        Film = FilmTitre()
        for Nom, duree in Film:
            maListe.append(Nom)
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['Film','maListe','duree','Nom','FilmTitre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n\r\n<form action="AffSeance" method="POST" class="needs-validation" novalidate>\r\n<div class="form-group">\r\n  <label class="choix" for="titre">Titre: </label>\r\n  <select class="form-control" name="titre" id="titre" required>\r\n')
        for i in range(len(maListe)):
            __M_writer('  <option value="')
            __M_writer(str(maListe[i]))
            __M_writer('">')
            __M_writer(str(maListe[i]))
            __M_writer('</option>\r\n')
        __M_writer('  </select>\r\n</div>\r\n<br><br>\r\n<button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n\r\n\r\n\r\n<br>\r\n\r\n<b>')
        __M_writer(str(Titre))
        __M_writer(' : </b>  <br><br>\r\n  ')
 
        maListe = []
        from Web import isoDate2String
        for titre,time,date in mesTitres :
            maListe.append((titre,time,isoDate2String(str(date)))) 
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['isoDate2String','titre','time','maListe','date'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for titre,time,date in maListe :
            __M_writer('Le ')
            __M_writer(str(date))
            __M_writer(' à ')
            __M_writer(str(time))
            __M_writer(' <br>\r\n')
        __M_writer('<br>\r\n\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/SearchBySeance.html", "uri": "SearchBySeance.html", "source_encoding": "utf-8", "line_map": {"27": 0, "39": 1, "40": 2, "41": 4, "42": 4, "43": 4, "44": 4, "45": 8, "46": 9, "47": 10, "48": 11, "49": 12, "50": 13, "51": 14, "52": 15, "55": 14, "56": 20, "57": 21, "58": 21, "59": 21, "60": 21, "61": 21, "62": 23, "63": 33, "64": 33, "65": 34, "66": 35, "67": 36, "68": 37, "69": 38, "70": 39, "71": 40, "74": 39, "75": 40, "76": 41, "77": 41, "78": 41, "79": 41, "80": 41, "81": 43, "87": 81}}
__M_END_METADATA
"""
