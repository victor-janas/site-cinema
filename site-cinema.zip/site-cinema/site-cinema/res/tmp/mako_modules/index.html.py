# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1684953856.0297658
_enable_loop = True
_template_filename = 'res/templates/index.html'
_template_uri = 'index.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template_index.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        __M_writer('\r\n        <div class="box">\r\n          <div class="border-right">\r\n            <div class="border-left">\r\n              <div class="inner" >\r\n                <h3>Bienvenue sur le site <span>Ducinema</span></h3>\r\n                <p class="adresse">23 rue de l\'ancien chateau d\'eau</p>\r\n                <div class="img-box1"><img src="res/images/1page-img1.webp" alt="film" width="240px"/>Lundi : 10h-23h<br><br> Mardi : 10h-23h<br><br> Mercredi : 10h-23h<br><br> Jeudi : 10h-23h<br><br> Vendredi : 10h-23h<br><br> Samedi : 10h-0h00<br><br> Dimanche : 10h-0h00<br>\r\n                </div>\r\n                <p class="contenu">10 salles <br>5 salles de 30 personnes et 5 salles de 50 personnes<br><b>Film de moins d\'1h30 : 4€<br>Film entre 1h30 et 3h : 5€<br>Film de plus de 3h : 3€<br>Film avec interdiction : prix + 1€</b><br>  (Prix fixe à l\'année)<br>Prix du parking : 50 centimes les deux heures </p>\r\n                <br><br>\r\n                <h1 class="menu">Menu et Offres</h1>\r\n                <br><br>\r\n                <div class="img-box1"><img src="res/images/menu.jpg" alt="film" width="402px"/>\r\n                <h4 class="info">Boissons</h4><br>\r\n                <p>\r\n                    Coca-cola.......................1€50<br>\r\n                    Coca-cola zéro...............1€50<br>\r\n                    Oasis tropical..................1€50<br>\r\n                    Oasis orange..................1€50<br>\r\n                    Fanta..............................1€50<br>\r\n                    Eau minérale..................1€<br>\r\n                    Café................................1€<br>\r\n                    Thé..................................1€<br>\r\n                </p><br>\r\n                <h4 class="info">Confiseries</h4><br>\r\n                <p>\r\n                    Pop corn.........................2€<br>\r\n                    Haribo croco...................1€50<br>\r\n                    Haribo dargibus..............1€50<br>\r\n                    Maltesers........................1€75<br>\r\n                    barbe à papa..................2€<br>\r\n                </p><br>>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      <div id="footer">\r\n        <div class="left">\r\n          <div class="right">\r\n            <div class="footerlink">\r\n              <p class="lf">Victor Janas SAE23</p>\r\n              <p class="rf">Site sur le cinéma</p>\r\n              <div style="clear:both;"></div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n')
        __M_writer('\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/index.html", "uri": "index.html", "source_encoding": "utf-8", "line_map": {"27": 0, "32": 1, "33": 53, "39": 33}}
__M_END_METADATA
"""
