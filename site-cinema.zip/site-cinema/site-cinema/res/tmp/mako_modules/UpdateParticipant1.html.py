# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685208176.623786
_enable_loop = True
_template_filename = 'res/templates/UpdateParticipant1.html'
_template_uri = 'UpdateParticipant1.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        type = context.get('type', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<p>Modification d\'un Participant</p>\r\n\r\n<div class="field">\r\n    <form id="contacts-form" action="UpdateParticipant1" method="POST" class="needs-validation" novalidate>\r\n      <fieldset>\r\n        <div class="form-group">\r\n          <label for="Nom">Nom:</label>\r\n          <input type="text" class="form-control" id="Nom" placeholder="Entrer le Nom" name="Nom" required>\r\n        </div>\r\n        <br>\r\n        <div class="form-group">\r\n            <label for="Prenom"> Prenom:</label>\r\n            <input type="text" class="form-control" id="Prenom" placeholder="Entrer le Prenom" name="Prenom" required>\r\n          </div>\r\n        <br>\r\n        <div class="field">\r\n          <label for="newnom">Nouveau nom:</label>\r\n          <input type="text" class="form-control" id="newnom" placeholder="Entrer le nouveau nom" name="newnom" required>\r\n        </div>\r\n        <br>\r\n        <div class="field">\r\n          <label for="newprenom">Nouveau prénom:</label>\r\n          <input type="text" class="form-control" id="newprenom" placeholder="Entrer le nouveau prenom" name="newprenom" required>\r\n        </div>\r\n        <br>\r\n        <div class="field">\r\n          <label for="Date">Date de Naissance:</label>\r\n          <input type="date" class="form-control" id="Date" placeholder="Entrer l\'année de Naissance" name="Date" required>  \r\n        </div>\r\n        <br>\r\n        <div class="field">\r\n            <label for="nati">Nationalité:</label>\r\n            <input type="text" class="form-control" id="nat" placeholder="Entrer la nationalité" name="nati" required>  \r\n          </div>\r\n        </fieldset>\r\n        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>\r\n        <button type="submit" class="btn btn-primary">Rechercher</button>\r\n      </form>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/UpdateParticipant1.html", "uri": "UpdateParticipant1.html", "source_encoding": "utf-8", "line_map": {"27": 0, "34": 1, "35": 2, "36": 4, "37": 4, "38": 4, "39": 4, "45": 39}}
__M_END_METADATA
"""
