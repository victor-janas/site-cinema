# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835451.801743
_enable_loop = True
_template_filename = 'res/templates/SearchByAnnee.html'
_template_uri = 'SearchByAnnee.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        mesTitres = context.get('mesTitres', UNDEFINED)
        len = context.get('len', UNDEFINED)
        range = context.get('range', UNDEFINED)
        type = context.get('type', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<h3 class="julien">Liste des Films</h3>\r\n\r\n')

        maListe = []
        from Web import FilmAnnee
        Year = FilmAnnee()
        for annee, titre in Year:
            maListe.append(annee)
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['annee','titre','FilmAnnee','Year','maListe'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n\r\n<form action="AffAnnee" method="POST" class="needs-validation" novalidate>\r\n  <div class="form-group">\r\n    <label class="choix" for="annee">Annee: </label>\r\n    <select class="form-control" name="annee" id="annee" required>\r\n')
        for i in range(len(maListe)):
            __M_writer('    <option value="')
            __M_writer(str(maListe[i]))
            __M_writer('">')
            __M_writer(str(maListe[i]))
            __M_writer('</option>\r\n')
        __M_writer('    </select>\r\n  </div>\r\n  <br><br>\r\n  <button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n\r\n\r\n<br>\r\n\r\n<b>')
        __M_writer(str(mesTitres))
        __M_writer(' </b> <br> \r\n\r\n\r\n')
        __M_writer('\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/SearchByAnnee.html", "uri": "SearchByAnnee.html", "source_encoding": "utf-8", "line_map": {"27": 0, "37": 1, "38": 2, "39": 4, "40": 4, "41": 4, "42": 4, "43": 7, "44": 8, "45": 9, "46": 10, "47": 11, "48": 12, "49": 13, "50": 14, "53": 13, "54": 19, "55": 20, "56": 20, "57": 20, "58": 20, "59": 20, "60": 22, "61": 31, "62": 31, "63": 34, "69": 63}}
__M_END_METADATA
"""
