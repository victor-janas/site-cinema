# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685836044.3919196
_enable_loop = True
_template_filename = 'res/templates/UpdateParticipant.html'
_template_uri = 'UpdateParticipant.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        mesTitres = context.get('mesTitres', UNDEFINED)
        str = context.get('str', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<h3 class="julien">Informations :</h3>\r\n\r\n')
  # code python pour changer l'affichage de la date!!!
        from Web import isoDate2String
        maListe = []
        for nom, prenom, date, nation in mesTitres :
            maListe.append((nom, prenom, isoDate2String(str(date)), nation)) 
            
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['isoDate2String','maListe','prenom','date','nom','nation'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for nom, prenom, date, nation in maListe :
            __M_writer('    <b>')
            __M_writer(str(prenom))
            __M_writer(' ')
            __M_writer(str(nom))
            __M_writer('</b> <br> né le ')
            __M_writer(str(date))
            __M_writer('  en ')
            __M_writer(str(nation))
            __M_writer(' <br>\r\n')
        __M_writer('\r\n')
        __M_writer('\r\n\r\n<br>\r\n<p class="modification">Modification d\'un Participant</p>\r\n\r\n\r\n<div class="field">\r\n<form id="contacts-form" action="UpdateParticipant1" method="POST" class="needs-validation" novalidate>\r\n  <fieldset>\r\n    <div class="form-group">\r\n      <label for="Nom">Nom:</label>\r\n      <input type="text" class="form-control" id="Nom" placeholder="Entrer le Nom" name="Nom" required>\r\n    </div>\r\n    <br>\r\n    <div class="form-group">\r\n        <label for="Prenom"> Prenom:</label>\r\n        <input type="text" class="form-control" id="Prenom" placeholder="Entrer le Prenom" name="Prenom" required>\r\n      </div>\r\n    <br>\r\n    <div class="field">\r\n      <label for="newnom">Nouveau nom:</label>\r\n      <input type="text" class="form-control" id="newnom" placeholder="Entrer le nouveau nom" name="newnom" required>\r\n    </div>\r\n    <br>\r\n    <div class="field">\r\n      <label for="newprenom">Nouveau prénom:</label>\r\n      <input type="text" class="form-control" id="newprenom" placeholder="Entrer le nouveau prenom" name="newprenom" required>\r\n    </div>\r\n    <br>\r\n    <div class="field">\r\n      <label for="Date">Date de Naissance:</label>\r\n      <input type="date" class="form-control" id="Date" placeholder="Entrer l\'année de Naissance" name="Date" required>  \r\n    </div>\r\n    <br>\r\n    <div class="field">\r\n        <label for="nati">Nationalité:</label>\r\n        <input type="text" class="form-control" id="nat" placeholder="Entrer la nationalité" name="nati" required>  \r\n      </div>\r\n    </fieldset>\r\n    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>\r\n    <button type="submit" class="btn btn-primary">Modifier</button>\r\n  </form>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/UpdateParticipant.html", "uri": "UpdateParticipant.html", "source_encoding": "utf-8", "line_map": {"27": 0, "34": 1, "35": 2, "36": 6, "37": 7, "38": 8, "39": 9, "40": 10, "41": 11, "42": 12, "45": 11, "46": 12, "47": 13, "48": 13, "49": 13, "50": 13, "51": 13, "52": 13, "53": 13, "54": 13, "55": 13, "56": 15, "57": 16, "63": 57}}
__M_END_METADATA
"""
