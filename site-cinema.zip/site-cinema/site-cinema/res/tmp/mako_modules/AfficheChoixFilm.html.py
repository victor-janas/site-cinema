# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1684955080.8970504
_enable_loop = True
_template_filename = 'res/templates/AfficheChoixFilm.html'
_template_uri = 'AfficheChoixFilm.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        type = context.get('type', UNDEFINED)
        message = context.get('message', UNDEFINED)
        range = context.get('range', UNDEFINED)
        len = context.get('len', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\n')
        __M_writer('\n<br>\n<h3 class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer(' :</h3>\n\n\n')

        maListe = []
        from Web import FilmTitre
        Film = FilmTitre()
        for Nom, duree in Film:
            maListe.append(Nom)
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['maListe','Film','duree','Nom','FilmTitre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\n\n<form action="AffFilm" method="POST" class="needs-validation" novalidate>\n  <div class="form-group">\n    <label class="choix" for="titre">Titre: </label>\n    <select class="form-control" name="titre" id="titre" required>\n')
        for i in range(len(maListe)):
            __M_writer('    <option value="')
            __M_writer(str(maListe[i]))
            __M_writer('">')
            __M_writer(str(maListe[i]))
            __M_writer('</option>\n')
        __M_writer('    </select>\n  </div>\n  <br><br>\n  <button type="submit" class="btn btn-primary">Rechercher</button>\n</form>\n\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/AfficheChoixFilm.html", "uri": "AfficheChoixFilm.html", "source_encoding": "utf-8", "line_map": {"27": 0, "36": 1, "37": 2, "38": 4, "39": 4, "40": 4, "41": 4, "42": 7, "43": 8, "44": 9, "45": 10, "46": 11, "47": 12, "48": 13, "49": 14, "52": 13, "53": 19, "54": 20, "55": 20, "56": 20, "57": 20, "58": 20, "59": 22, "65": 59}}
__M_END_METADATA
"""
