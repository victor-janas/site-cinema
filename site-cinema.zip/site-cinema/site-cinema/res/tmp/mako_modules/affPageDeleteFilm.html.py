# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1684965332.6149085
_enable_loop = True
_template_filename = 'res/templates/affPageDeleteFilm.html'
_template_uri = 'affPageDeleteFilm.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        type = context.get('type', UNDEFINED)
        len = context.get('len', UNDEFINED)
        message = context.get('message', UNDEFINED)
        range = context.get('range', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer("</p>\r\n<p>Suppression d'un film</p>\r\n\r\n")

        maListe = []
        from Web import FilmTitre
        Film = FilmTitre()
        for Nom, duree in Film:
            maListe.append(Nom)
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['Nom','Film','maListe','duree','FilmTitre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n\r\n<form action="DeleteFilm" method="POST" class="needs-validation" novalidate>\r\n  <div class="form-group">\r\n    <label class="choix" for="titre">Titre: </label>\r\n    <select class="form-control" name="titre" id="titre" required>\r\n')
        for i in range(len(maListe)):
            __M_writer('    <option value="')
            __M_writer(str(maListe[i]))
            __M_writer('">')
            __M_writer(str(maListe[i]))
            __M_writer('</option>\r\n')
        __M_writer('    </select>\r\n  </div>\r\n  <br><br>\r\n  <button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/affPageDeleteFilm.html", "uri": "affPageDeleteFilm.html", "source_encoding": "utf-8", "line_map": {"27": 0, "36": 1, "37": 3, "38": 3, "39": 3, "40": 3, "41": 6, "42": 7, "43": 8, "44": 9, "45": 10, "46": 11, "47": 12, "48": 13, "51": 12, "52": 18, "53": 19, "54": 19, "55": 19, "56": 19, "57": 19, "58": 21, "64": 58}}
__M_END_METADATA
"""
