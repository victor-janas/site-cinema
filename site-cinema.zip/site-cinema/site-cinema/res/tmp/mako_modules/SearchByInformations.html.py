# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835404.5726004
_enable_loop = True
_template_filename = 'res/templates/SearchByInformations.html'
_template_uri = 'SearchByInformations.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        mesTitres = context.get('mesTitres', UNDEFINED)
        len = context.get('len', UNDEFINED)
        range = context.get('range', UNDEFINED)
        Titre = context.get('Titre', UNDEFINED)
        type = context.get('type', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<h3 class="julien">Liste des horaires</h3>\r\n\r\n')
        __M_writer('\r\n\r\n\r\n  ')

        maListe = []
        from Web import FilmTitre
        Film = FilmTitre()
        for Nom, duree in Film:
            maListe.append(Nom)
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['Film','maListe','duree','Nom','FilmTitre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n\r\n<form action="AffInformations" method="POST" class="needs-validation" novalidate>\r\n<div class="form-group">\r\n  <label class="choix" for="titre">Titre: </label>\r\n  <select class="form-control" name="titre" id="titre" required>\r\n')
        for i in range(len(maListe)):
            __M_writer('  <option value="')
            __M_writer(str(maListe[i]))
            __M_writer('">')
            __M_writer(str(maListe[i]))
            __M_writer('</option>\r\n')
        __M_writer('  </select>\r\n</div>\r\n<br><br>\r\n<button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n\r\n\r\n\r\n<br>\r\n\r\n<b>')
        __M_writer(str(Titre))
        __M_writer(' : </b>  <br><br>\r\n  ')
  
        maListe = []
        for a, b, in mesTitres :
            maListe.append((a,b)) 
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['a','maListe','b'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n<p>Le(s) réalisateur(s) et le(s) acteur(s) :</p>\r\n')
        for a,b, in maListe :
            __M_writer(' ')
            __M_writer(str(a))
            __M_writer(' ')
            __M_writer(str(b))
            __M_writer('<br>\r\n')
        __M_writer('<br>\r\n\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/SearchByInformations.html", "uri": "SearchByInformations.html", "source_encoding": "utf-8", "line_map": {"27": 0, "38": 1, "39": 2, "40": 4, "41": 4, "42": 4, "43": 4, "44": 7, "45": 10, "46": 11, "47": 12, "48": 13, "49": 14, "50": 15, "51": 16, "52": 17, "55": 16, "56": 22, "57": 23, "58": 23, "59": 23, "60": 23, "61": 23, "62": 25, "63": 35, "64": 35, "65": 36, "66": 37, "67": 38, "68": 39, "69": 40, "70": 41, "73": 40, "74": 42, "75": 43, "76": 43, "77": 43, "78": 43, "79": 43, "80": 45, "86": 80}}
__M_END_METADATA
"""
