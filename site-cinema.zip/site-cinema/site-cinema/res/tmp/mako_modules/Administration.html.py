# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685211317.7326493
_enable_loop = True
_template_filename = 'res/templates/Administration.html'
_template_uri = 'Administration.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template_Administration.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        __M_writer('\r\n      <div id="content">\r\n        <div class="line-hor"></div>\r\n        <div class="box">\r\n          <div class="border-right">\r\n            <div class="border-left">\r\n              <div class="inner">\r\n                <h3>Notre <span>Administration</span></h3>\r\n                <p>Bienvenue sur notre page d\'administration dédiée à la gestion des films ! Cette plateforme puissante et conviviale vous permet de gérer facilement les informations des films, y compris l\'ajout, la modification et la suppression.</p>            \r\n                <p>Grâce à notre interface intuitive, vous pouvez insérer de nouveaux films dans notre base de données en remplissant les détails pertinents tels que le titre, le réalisateur, les acteurs principaux, le genre, l\'année de sortie et bien plus encore. Vous pouvez également télécharger des affiches attrayantes pour donner vie aux fiches des films.</p>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div id="footer">\r\n        <div class="left">\r\n          <div class="right">\r\n            <div class="footerlink">\r\n              <p class="lf">Victor Janas SAE23</p>\r\n              <p class="rf">Site sur le cinéma</p>\r\n              <div style="clear:both;"></div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n')
        __M_writer('\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/Administration.html", "uri": "Administration.html", "source_encoding": "utf-8", "line_map": {"27": 0, "32": 1, "33": 30, "39": 33}}
__M_END_METADATA
"""
