# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1684791055.4174857
_enable_loop = True
_template_filename = 'res/templates/aff_prix.html'
_template_uri = 'aff_prix.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        monEtud = context.get('monEtud', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<h3 class="julien">Les films classés par prix :</h3>\r\n')
 
        maListe = []
        from Web import convertir_minutes_en_heures
        for titre, duree, annee, catego, interdi, prix in monEtud :
            maListe.append((titre, convertir_minutes_en_heures(duree), annee, catego, interdi, prix)) 
            
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['duree','prix','maListe','annee','interdi','convertir_minutes_en_heures','catego','titre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for titre, duree, annee, catego, interdi, prix in maListe :
            __M_writer('    <p><b>')
            __M_writer(str(titre))
            __M_writer('</b> : ')
            __M_writer(str(duree))
            __M_writer(', ')
            __M_writer(str(annee))
            __M_writer(', ')
            __M_writer(str(catego))
            __M_writer(', ')
            __M_writer(str(interdi))
            __M_writer(', ')
            __M_writer(str(prix))
            __M_writer('€</p><br/>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/aff_prix.html", "uri": "aff_prix.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 4, "35": 5, "36": 6, "37": 7, "38": 8, "39": 9, "40": 10, "43": 9, "44": 10, "45": 11, "46": 11, "47": 11, "48": 11, "49": 11, "50": 11, "51": 11, "52": 11, "53": 11, "54": 11, "55": 11, "56": 11, "57": 11, "63": 57}}
__M_END_METADATA
"""
