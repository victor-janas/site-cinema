# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685834193.8357008
_enable_loop = True
_template_filename = 'res/templates/aff_info.html'
_template_uri = 'aff_info.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        mesEtud = context.get('mesEtud', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<h3 class="julien">Liste des Films avec toutes leurs informations</h3>\r\n<h4><b>Titre</b> :  durée, Année de parution, genre, Interdiction aux mineurs, Prix</h4>\r\n\r\n    ')

        maListe = []
        from Web import convertir_minutes_en_heures
        for titre, duree, annee, catego, interdi, prix in mesEtud :
            maListe.append((titre, convertir_minutes_en_heures(duree), annee, catego, interdi, prix)) 
            
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['convertir_minutes_en_heures','interdi','catego','duree','prix','maListe','annee','titre'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for titre, duree, annee, catego, interdi, prix in maListe :
            __M_writer('    <p><b>')
            __M_writer(str(titre))
            __M_writer('</b> : ')
            __M_writer(str(duree))
            __M_writer(', ')
            __M_writer(str(annee))
            __M_writer(', ')
            __M_writer(str(catego))
            __M_writer(', ')
            __M_writer(str(interdi))
            __M_writer(', ')
            __M_writer(str(prix))
            __M_writer('€</p><br/>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/aff_info.html", "uri": "aff_info.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 6, "35": 7, "36": 8, "37": 9, "38": 10, "39": 11, "40": 12, "43": 11, "44": 12, "45": 13, "46": 13, "47": 13, "48": 13, "49": 13, "50": 13, "51": 13, "52": 13, "53": 13, "54": 13, "55": 13, "56": 13, "57": 13, "63": 57}}
__M_END_METADATA
"""
