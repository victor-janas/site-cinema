# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835591.0571406
_enable_loop = True
_template_filename = 'res/templates/SearchBySalle.html'
_template_uri = 'SearchBySalle.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        mesTitres = context.get('mesTitres', UNDEFINED)
        type = context.get('type', UNDEFINED)
        Salle = context.get('Salle', UNDEFINED)
        str = context.get('str', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<h3 class="julien">Liste des Films</h3>\r\n\r\n<form action="AffSalle" method="POST" class="needs-validation" novalidate>\r\n    <div class="form-group">\r\n      <label for="salle">salle:</label>\r\n      <select class="form-control" name="salle" id="salle" required>\r\n          <option value="1">1</option>\r\n          <option value="2">2</option>\r\n          <option value="3">3</option>\r\n          <option value="4">4</option>\r\n          <option value="5">5</option>\r\n          <option value="6">6</option>\r\n          <option value="7">7</option>\r\n          <option value="8">8</option>\r\n          <option value="9">9</option>\r\n          <option value="10">10</option>\r\n      </select>\r\n    </div>\r\n    <br>\r\n    <button type="submit" class="btn btn-primary">Rechercher</button>\r\n  </form>\r\n\r\n<br>\r\n  <p>Dans la salle ')
        __M_writer(str(Salle))
        __M_writer('  :<br></p>\r\n  ')

        maListe = []
        from Web import isoDate2String
        for titre,time,date in mesTitres :
            maListe.append((titre,time,isoDate2String(str(date)))) 
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['isoDate2String','titre','time','maListe','date'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for titre,time,date in maListe :
            __M_writer('Le ')
            __M_writer(str(date))
            __M_writer(' à ')
            __M_writer(str(time))
            __M_writer(' : ')
            __M_writer(str(titre))
            __M_writer(' <br>\r\n')
        __M_writer('\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/SearchBySalle.html", "uri": "SearchBySalle.html", "source_encoding": "utf-8", "line_map": {"27": 0, "37": 1, "38": 2, "39": 4, "40": 4, "41": 4, "42": 4, "43": 28, "44": 28, "45": 29, "46": 30, "47": 31, "48": 32, "49": 33, "50": 34, "51": 35, "54": 34, "55": 35, "56": 36, "57": 36, "58": 36, "59": 36, "60": 36, "61": 36, "62": 36, "63": 38, "69": 63}}
__M_END_METADATA
"""
