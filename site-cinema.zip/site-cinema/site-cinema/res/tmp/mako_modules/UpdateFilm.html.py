# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685836033.5809872
_enable_loop = True
_template_filename = 'res/templates/UpdateFilm.html'
_template_uri = 'UpdateFilm.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        mesTitres = context.get('mesTitres', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n\r\n\r\n\r\n<br>\r\n')
 
        maListe = []
        from Web import convertir_minutes_en_heures
        for titre, duree, annee, catego, desc, interdi, prix in mesTitres :
            maListe.append((titre, convertir_minutes_en_heures(duree), annee, catego, desc, interdi, prix)) 
            
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['catego','interdi','annee','convertir_minutes_en_heures','titre','desc','maListe','duree','prix'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n')
        for titre, duree, annee, catego, desc, interdi, prix in maListe :
            __M_writer('    <b>')
            __M_writer(str(titre))
            __M_writer('</b> :<br>durée: ')
            __M_writer(str(duree))
            __M_writer(' minutes <br>')
            __M_writer(str(annee))
            __M_writer(' <br>')
            __M_writer(str(catego))
            __M_writer(' <br>')
            __M_writer(str(desc))
            __M_writer(' <br>Interdiction : ')
            __M_writer(str(interdi))
            __M_writer(' <br>Prix: ')
            __M_writer(str(prix))
            __M_writer('€<br/>\r\n')
        __M_writer('\r\n')
        __M_writer('\r\n\r\n\r\n\r\n<br>\r\n<p>Modification d\'un film</p>\r\n\r\n<div class="field">\r\n<form id="contacts-form" action="UpdateFilm1" method="POST" class="needs-validation" novalidate>\r\n  <fieldset>\r\n    <div class="form-group">\r\n      <label for="titre">Titre:</label>\r\n      <input type="text" class="form-control" id="titre" placeholder="Entrer le titre" name="titre" required>\r\n    </div>\r\n    <br>\r\n    <div class="form-group">\r\n        <label for="newtitre">Nouveau Titre:</label>\r\n        <input type="text" class="form-control" id="newtitre" placeholder="Entrer le nouveau titre" name="newtitre" required>\r\n      </div>\r\n    <br>\r\n    <div class="field">\r\n      <label for="duree">Duree en minutes:</label>\r\n      <input type="text" class="form-control" id="duree" placeholder="Entrer la duree" name="duree" required>\r\n    </div>\r\n    <br>\r\n    <div class="field">\r\n      <label for="annee">Réalisé en :</label>\r\n      <input type="text" class="form-control" id="annee" placeholder="Entrer l\'année de Tournage" name="annee" required>\r\n    </div>\r\n    <br>\r\n    <div class="field">\r\n        <label for="catego">Categorie:</label>\r\n        <select class="form-control" name="catego" id="catego" required>\r\n            <option value="policier">policier</option>\r\n            <option value="fantastique">fantastique</option>\r\n            <option value="aventure">aventure</option>\r\n            <option value="psychologique">psychologique</option>\r\n            <option value="documentaire">documentaire</option>\r\n            <option value="historique">historique</option>\r\n            <option value="autre">autre</option>\r\n        </select> \r\n    </div>\r\n    <br>\r\n    <div class="field">\r\n      <label for="desc">Description:</label>\r\n      <input type="text" class="form-control" id="desc" placeholder="Entrer la description" name="desc" required>  \r\n    </div>\r\n    <br>\r\n    <div class="field">\r\n        <label for="inter">Interdiction:</label>\r\n        <select class="form-control" name="inter" id="inter" required>\r\n            <option value="non">Non</option>\r\n            <option value="oui">Oui</option>\r\n        </select>\r\n    </div>\r\n    <br>\r\n    <div class="field">\r\n      <label for="prix">Prix:</label>\r\n      <input type="text" class="form-control" id="prix" placeholder="prix" name="prix" required>  \r\n    </div>\r\n    </fieldset>\r\n    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>\r\n    <button type="submit" class="btn btn-primary">Modifier</button>\r\n  </form>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/UpdateFilm.html", "uri": "UpdateFilm.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 2, "35": 8, "36": 9, "37": 10, "38": 11, "39": 12, "40": 13, "41": 14, "44": 13, "45": 14, "46": 15, "47": 15, "48": 15, "49": 15, "50": 15, "51": 15, "52": 15, "53": 15, "54": 15, "55": 15, "56": 15, "57": 15, "58": 15, "59": 15, "60": 15, "61": 17, "62": 18, "68": 62}}
__M_END_METADATA
"""
