# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685835506.7389505
_enable_loop = True
_template_filename = 'res/templates/SearchByDate.html'
_template_uri = 'SearchByDate.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        mesTitres = context.get('mesTitres', UNDEFINED)
        type = context.get('type', UNDEFINED)
        Date = context.get('Date', UNDEFINED)
        str = context.get('str', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n<br>\r\n<p class="')
        __M_writer(str(type))
        __M_writer('">')
        __M_writer(str(message))
        __M_writer('</p>\r\n<h3 class="julien">Liste des séances</h3>\r\n\r\n<form action="AffDate" method="POST" class="needs-validation" novalidate>\r\n    <div class="form-group">\r\n        <label class="form">\r\n        <label for="date">Saisir la date :</label>\r\n        <input type="date" class="form-control" id="date" placeholder="Date" name="date" required>\r\n        </label>\r\n  </div>\r\n  <br>\r\n  <button type="submit" class="btn btn-primary">Rechercher</button>\r\n</form>\r\n\r\n')

        from Web import isoDate2String
        truc=isoDate2String(str(Date))
        maListe = []
        for titre,horaire in mesTitres :
            maListe.append((titre,horaire)) 
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['isoDate2String','titre','horaire','maListe','truc'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(' \r\n<p>Le ')
        __M_writer(str(truc))
        __M_writer(':<br></p>\r\n')
        for titre,horaire in maListe :
            __M_writer(str(titre))
            __M_writer(' : <b>')
            __M_writer(str(horaire))
            __M_writer(' </b> <br> \r\n')
        __M_writer('\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/SearchByDate.html", "uri": "SearchByDate.html", "source_encoding": "utf-8", "line_map": {"27": 0, "37": 1, "38": 2, "39": 4, "40": 4, "41": 4, "42": 4, "43": 18, "44": 19, "45": 20, "46": 21, "47": 22, "48": 23, "49": 24, "50": 25, "53": 24, "54": 25, "55": 25, "56": 26, "57": 27, "58": 27, "59": 27, "60": 27, "61": 29, "67": 61}}
__M_END_METADATA
"""
